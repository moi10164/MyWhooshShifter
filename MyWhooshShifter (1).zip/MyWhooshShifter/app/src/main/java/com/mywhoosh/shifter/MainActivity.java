package com.mywhoosh.shifter;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MyWhooshShifter";
    private static final int REQUEST_PERMISSIONS = 100;
    private static final int REQUEST_ENABLE_BT = 101;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothHidDevice hidDevice;
    private BluetoothDevice connectedDevice;
    private BluetoothHidDeviceAppSdpSettings sdpSettings;

    private TextView tvStatus;
    private TextView tvGear;
    private TextView tvDeviceName;
    private Button btnGearUp;
    private Button btnGearDown;
    private Button btnConnect;
    private View statusDot;

    private int currentGear = 15; // Default gear in MyWhoosh
    private static final int MIN_GEAR = 1;
    private static final int MAX_GEAR = 30;

    private boolean isConnected = false;
    private Vibrator vibrator;
    private Handler handler = new Handler(Looper.getMainLooper());

    // HID Report Descriptor for keyboard
    private static final byte[] KEYBOARD_DESCRIPTOR = {
        (byte) 0x05, (byte) 0x01, // Usage Page (Generic Desktop)
        (byte) 0x09, (byte) 0x06, // Usage (Keyboard)
        (byte) 0xA1, (byte) 0x01, // Collection (Application)
        (byte) 0x05, (byte) 0x07, // Usage Page (Key Codes)
        (byte) 0x19, (byte) 0xe0, // Usage Minimum (224)
        (byte) 0x29, (byte) 0xe7, // Usage Maximum (231)
        (byte) 0x15, (byte) 0x00, // Logical Minimum (0)
        (byte) 0x25, (byte) 0x01, // Logical Maximum (1)
        (byte) 0x75, (byte) 0x01, // Report Size (1)
        (byte) 0x95, (byte) 0x08, // Report Count (8)
        (byte) 0x81, (byte) 0x02, // Input (Data, Variable, Absolute)
        (byte) 0x95, (byte) 0x01, // Report Count (1)
        (byte) 0x75, (byte) 0x08, // Report Size (8)
        (byte) 0x81, (byte) 0x03, // Input (Constant)
        (byte) 0x95, (byte) 0x05, // Report Count (5)
        (byte) 0x75, (byte) 0x01, // Report Size (1)
        (byte) 0x05, (byte) 0x08, // Usage Page (LEDs)
        (byte) 0x19, (byte) 0x01, // Usage Minimum (1)
        (byte) 0x29, (byte) 0x05, // Usage Maximum (5)
        (byte) 0x91, (byte) 0x02, // Output (Data, Variable, Absolute)
        (byte) 0x95, (byte) 0x01, // Report Count (1)
        (byte) 0x75, (byte) 0x03, // Report Size (3)
        (byte) 0x91, (byte) 0x03, // Output (Constant)
        (byte) 0x95, (byte) 0x06, // Report Count (6)
        (byte) 0x75, (byte) 0x08, // Report Size (8)
        (byte) 0x15, (byte) 0x00, // Logical Minimum (0)
        (byte) 0x25, (byte) 0x65, // Logical Maximum (101)
        (byte) 0x05, (byte) 0x07, // Usage Page (Key Codes)
        (byte) 0x19, (byte) 0x00, // Usage Minimum (0)
        (byte) 0x29, (byte) 0x65, // Usage Maximum (101)
        (byte) 0x81, (byte) 0x00, // Input (Data, Array)
        (byte) 0xC0              // End Collection
    };

    // HID keycodes
    private static final byte KEY_I = 0x0C; // 'i' key HID keycode
    private static final byte KEY_K = 0x0E; // 'k' key HID keycode

    private final BluetoothHidDevice.Callback hidCallback = new BluetoothHidDevice.Callback() {
        @Override
        public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean registered) {
            Log.d(TAG, "onAppStatusChanged: " + registered);
            if (registered) {
                runOnUiThread(() -> tvStatus.setText("HID enregistré - En attente de connexion..."));
            }
        }

        @Override
        public void onConnectionStateChanged(BluetoothDevice device, int state) {
            Log.d(TAG, "onConnectionStateChanged: " + state);
            runOnUiThread(() -> {
                if (state == BluetoothProfile.STATE_CONNECTED) {
                    connectedDevice = device;
                    isConnected = true;
                    String name = "Inconnu";
                    if (ActivityCompat.checkSelfPermission(MainActivity.this, 
                            Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                        name = device.getName() != null ? device.getName() : device.getAddress();
                    }
                    tvDeviceName.setText("📡 " + name);
                    setConnectedState(true);
                } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                    connectedDevice = null;
                    isConnected = false;
                    tvDeviceName.setText("Non connecté");
                    setConnectedState(false);
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Keep screen on during workout
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        initViews();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            showToast("Bluetooth non supporté sur cet appareil");
            return;
        }

        checkPermissionsAndSetup();
        setupButtons();
    }

    private void initViews() {
        tvStatus = findViewById(R.id.tv_status);
        tvGear = findViewById(R.id.tv_gear);
        tvDeviceName = findViewById(R.id.tv_device_name);
        btnGearUp = findViewById(R.id.btn_gear_up);
        btnGearDown = findViewById(R.id.btn_gear_down);
        btnConnect = findViewById(R.id.btn_connect);
        statusDot = findViewById(R.id.status_dot);
        updateGearDisplay();
    }

    private void setupButtons() {
        btnGearUp.setOnClickListener(v -> shiftGear(true));
        btnGearDown.setOnClickListener(v -> shiftGear(false));
        btnConnect.setOnClickListener(v -> {
            if (isConnected) {
                disconnectDevice();
            } else {
                connectToDevice();
            }
        });

        // Long press on gear up/down for rapid shifting
        btnGearUp.setOnLongClickListener(v -> {
            startRapidShift(true);
            return true;
        });
        btnGearDown.setOnLongClickListener(v -> {
            startRapidShift(false);
            return true;
        });

        btnGearUp.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                stopRapidShift();
            }
            return false;
        });

        btnGearDown.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                stopRapidShift();
            }
            return false;
        });
    }

    private Runnable rapidShiftRunnable;
    private boolean isRapidShifting = false;

    private void startRapidShift(boolean up) {
        isRapidShifting = true;
        rapidShiftRunnable = new Runnable() {
            @Override
            public void run() {
                if (isRapidShifting) {
                    shiftGear(up);
                    handler.postDelayed(this, 300);
                }
            }
        };
        handler.post(rapidShiftRunnable);
    }

    private void stopRapidShift() {
        isRapidShifting = false;
        if (rapidShiftRunnable != null) {
            handler.removeCallbacks(rapidShiftRunnable);
        }
    }

    private void shiftGear(boolean up) {
        if (up) {
            if (currentGear < MAX_GEAR) {
                currentGear++;
                sendKeyPress(KEY_I);
                vibrateShift(true);
            } else {
                showToast("Vitesse maximale (30) atteinte");
                vibrateLimit();
            }
        } else {
            if (currentGear > MIN_GEAR) {
                currentGear--;
                sendKeyPress(KEY_K);
                vibrateShift(false);
            } else {
                showToast("Vitesse minimale (1) atteinte");
                vibrateLimit();
            }
        }
        updateGearDisplay();
    }

    private void updateGearDisplay() {
        tvGear.setText(String.valueOf(currentGear));

        // Change color based on gear range
        int color;
        if (currentGear <= 10) {
            color = getResources().getColor(R.color.gear_low, null);
        } else if (currentGear <= 20) {
            color = getResources().getColor(R.color.gear_mid, null);
        } else {
            color = getResources().getColor(R.color.gear_high, null);
        }
        tvGear.setTextColor(color);
    }

    private void sendKeyPress(byte keyCode) {
        if (!isConnected || hidDevice == null || connectedDevice == null) {
            // Demo mode - just update UI
            Log.d(TAG, "Demo mode - key: " + keyCode);
            return;
        }

        try {
            // Key down
            byte[] report = new byte[]{0x00, 0x00, keyCode, 0x00, 0x00, 0x00, 0x00, 0x00};
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) 
                    == PackageManager.PERMISSION_GRANTED) {
                hidDevice.sendReport(connectedDevice, 0, report);
                
                // Key up after short delay
                handler.postDelayed(() -> {
                    byte[] releaseReport = new byte[]{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
                    try {
                        hidDevice.sendReport(connectedDevice, 0, releaseReport);
                    } catch (Exception e) {
                        Log.e(TAG, "Error releasing key", e);
                    }
                }, 50);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error sending key", e);
        }
    }

    private void vibrateShift(boolean up) {
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Two quick pulses for up, one for down
            if (up) {
                vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 40, 60, 40}, -1));
            } else {
                vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE));
            }
        } else {
            vibrator.vibrate(50);
        }
    }

    private void vibrateLimit() {
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 100, 50, 100}, -1));
        } else {
            vibrator.vibrate(200);
        }
    }

    private void checkPermissionsAndSetup() {
        List<String> permissions = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                    != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE)
                    != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH)
                    != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
        }

        if (!permissions.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), REQUEST_PERMISSIONS);
        } else {
            setupBluetooth();
        }
    }

    private void setupBluetooth() {
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED) {
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            return;
        }
        initHidProfile();
    }

    private void initHidProfile() {
        sdpSettings = new BluetoothHidDeviceAppSdpSettings(
                "MyWhoosh Shifter",
                "Virtual Gear Controller",
                "MyWhoosh",
                BluetoothHidDevice.SUBCLASS1_COMBO,
                KEYBOARD_DESCRIPTOR
        );

        Executor executor = ContextCompat.getMainExecutor(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED) {
            bluetoothAdapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
                @Override
                public void onServiceConnected(int profile, BluetoothProfile proxy) {
                    if (profile == BluetoothProfile.HID_DEVICE) {
                        hidDevice = (BluetoothHidDevice) proxy;
                        hidDevice.registerApp(sdpSettings, null, null, executor, hidCallback);
                        runOnUiThread(() -> tvStatus.setText("HID initialisé - Prêt à connecter"));
                    }
                }

                @Override
                public void onServiceDisconnected(int profile) {
                    hidDevice = null;
                    runOnUiThread(() -> setConnectedState(false));
                }
            }, BluetoothProfile.HID_DEVICE);
        }
    }

    private void connectToDevice() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            showToast("Bluetooth désactivé");
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            showToast("Permission Bluetooth manquante");
            return;
        }

        // Show list of paired devices
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.isEmpty()) {
            showToast("Aucun appareil jumelé. Jumelez d'abord votre PC via les paramètres Bluetooth Android.");
            return;
        }

        // Try to connect to first paired device (PC)
        // In a real app, show a picker dialog
        showDevicePicker(pairedDevices);
    }

    private void showDevicePicker(Set<BluetoothDevice> devices) {
        String[] names = new String[devices.size()];
        final BluetoothDevice[] deviceArray = devices.toArray(new BluetoothDevice[0]);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) return;

        for (int i = 0; i < deviceArray.length; i++) {
            String name = deviceArray[i].getName();
            names[i] = name != null ? name : deviceArray[i].getAddress();
        }

        new android.app.AlertDialog.Builder(this)
                .setTitle("Sélectionner l'appareil MyWhoosh")
                .setItems(names, (dialog, which) -> {
                    connectToBluetoothDevice(deviceArray[which]);
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void connectToBluetoothDevice(BluetoothDevice device) {
        if (hidDevice == null) {
            showToast("Service HID non initialisé");
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) return;

        tvStatus.setText("Connexion à " + device.getName() + "...");
        hidDevice.connect(device);
    }

    private void disconnectDevice() {
        if (hidDevice != null && connectedDevice != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED) {
                hidDevice.disconnect(connectedDevice);
            }
        }
    }

    private void setConnectedState(boolean connected) {
        isConnected = connected;
        if (connected) {
            statusDot.setBackgroundResource(R.drawable.dot_connected);
            tvStatus.setText("✅ Connecté - Prêt à pédaler !");
            btnConnect.setText("Déconnecter");
            btnConnect.setBackgroundTintList(getResources().getColorStateList(R.color.disconnect_red, null));
        } else {
            statusDot.setBackgroundResource(R.drawable.dot_disconnected);
            tvStatus.setText("⚡ Non connecté - Appuyez sur Connecter");
            btnConnect.setText("Connecter PC");
            btnConnect.setBackgroundTintList(getResources().getColorStateList(R.color.connect_green, null));
            tvDeviceName.setText("Non connecté");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                setupBluetooth();
            } else {
                showToast("Permissions Bluetooth requises pour fonctionner");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT && resultCode == RESULT_OK) {
            initHidProfile();
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopRapidShift();
        disconnectDevice();
    }
}
